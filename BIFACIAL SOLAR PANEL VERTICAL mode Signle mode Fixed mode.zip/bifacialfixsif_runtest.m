clc;
close all;
clear all;

n=15;
l=23.5;
long=90.40;

[timlet,tttotalf,Energy_S]=bifacialfixsif(n,l,long);
(n,l,long);
[timle,tttotals,bitop,Energy_SS]=bifacialsinglesif(n,l,long);
[tttotalv,Energy_V]=bifacialverticalsif(n,l,long);

Energy_S
%Energy_m
Energy_SS
Energy_V
Time=timle;
figure(500)
plot(Time,tttotalf,'--',Time,tttotalv,'-.',Time,tttotals,'k'),legend('Bifacial Fixed','Vertical Vertical','Bifacial Single');
xlabel('Time(Hours)')
ylabel('Irrediance(Watt/m^2)')