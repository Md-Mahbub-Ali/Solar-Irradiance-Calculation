function [tttotal,Energy_S]=bifacialverticalsif(n,l,long)
% n=15;
% l=23.5;
% long=90.40;
n
q=23.45;
a= q*(sind((n+284)*(360/365)));
tlt = 23.5;
AA = 1160+75*sind((360/365)*(n-275));
kk = 0.174+0.035*sind((360/365)*(n-100));
cc = 0.095+(0.04*sind((360/365)*(n-100)));
alb = 0.4;
Sr=12-((1/15)*(acosd(-tand(l)*tand(a))));%sunrise time
Ss=12+((1/15)*(acosd(-tand(l)*tand(a))));% sunset time
intsr=floor(Sr)+1;
intss=floor(Ss);
Ws=acosd((-tand(l)*tand(a)));%sunrise angle
T=Ss-Sr;%total day time

timle=[Sr,intsr:0.25:intss,Ss];
p=length(timle);

for i=1:(p)
     ws1=(-Ws+(((2*Ws)/T)*(timle(i)-Sr)));%hour angle
% if(timle(i)>10)&&(timle(i)<14)
%    ws=90;
% else
% ws=ws;
% end 
%------------
ws=ws1;
% z1=90-ws;
%  y=cosd(z1);
% b=sind(z1);
% x=b*sind(tlt);
% z=b*cosd(tlt);
% vf=[0 0 0];
% vf(1)=x;
% vf(2)=y;
% vf(3)=z;
% nn=[0 0 1];
% gg=sqrt(vf*vf');
% hh=sqrt(nn*nn');
% betaa=acosd(dot(vf,nn)/(gg*hh));
%--------------
%bft=acosd(cosd(ws)*cosd(23.5)); % beta/tilt too
  % -----------------
  beta=90;
%   refactp = ((1+cosd(beta))/2);
% difactm = ((1-cosd(beta))/2); %sky
refactprear = ((1+cosd(beta))/2);
difactmrear = ((1-cosd(beta))/2); %sky
%refactpf = ((1-cosd(beta))/2);
difactmf = ((1+cosd(beta))/2); %sky
A=asind((sind(a)*sind(l))+(cosd(a)*cosd(l)*cosd(ws)));%solar altitude angle
Za=90-A;%zenith angle
AM=(1/cosd(Za));
fys=asind((cosd(a)*sind(ws))/cosd(A));
fi2=asind(sind(ws1)/(sind(beta))); %if surface azimuthal exist buddy

kosh= ((cosd(A)*abs(cosd(fys-90))*sind(beta))+(sind(A)*cosd(beta)));
%kosh2=((sind(l-beta)*sind(a))+(cosd(l-beta)*cosd(a)*cosd(ws)));
po = exp(-0.0000361*0);
%Ib = AA*(exp(-kk*AM*po));
Ib = AA*(exp(-kk*AM));
if(Ib==inf)
    Ib=0;
else
    Ib=AA*(exp(-kk*AM));
end
Io=1367*((0.7)^(AM^(0.678)));

% idt(i) = cc*Ib*difactm;
% irt1(i) = alb*Ib*(sind(A)+cc)*refactp;
%irt(i) = irt1(i)*1.1;
%irt2(i)= irt1(i)*.1;


Idrect(i) = Ib*kosh;
idtrear = cc*Ib*difactmrear;
irtrear = alb*Ib*(sind(A)+cc)*refactprear;

idtfront = cc*Ib*difactmf;

if(timle(i)>11.5)&&(timle(i)<12.5)
    I(i)=idtfront;
Irear(i) =idtfront;
else
   I(i)=Idrect(i); 
Irear(i) = idtfront;
end 
  
%total(i)= irt1(i)+idt(i);
%ttotal(i)=idt(i)+irt(i)+Idrect(i);
%tttotal(i)= idt(i)+irt1(i)+Idrect(i);
%trtotal(i)=idt(i)+irt2(i)+Idrect(i);
tttotal(i) = Irear(i)+I(i);

end
figure(400)
X=sum(tttotal);
Energy_S=X*0.25;
TotalDirect=sum(Idrect);
plot(timle,tttotal,'k',timle,I,'-.',timle,Irear,'-'),legend('Total Power', 'POWER','POWER REAR');
title('(SIFAT)Solar Irrediance of Bifacial VERTICAL January 15')
xlabel('Time(Hours)')
ylabel('Irrediance(Watt/m^2)')
end