function [timlet,tttotal,Energy_S]=bifacialfixsif(n,l,long)
n;
l=23.5;
long=90.40;
q=23.45;
a= q*(sind((n+284)*(360/365)));
tlt = 23.5;
AA = 1160+75*sind((360/365)*(n-275));
kk = 0.174+0.035*sind((360/365)*(n-100));
cc = 0.095+(0.04*sind((360/365)*(n-100)));
alb = 0.4;
Sr=12-((1/15)*(acosd(-tand(l)*tand(a))));%sunrise time
Ss=12+((1/15)*(acosd(-tand(l)*tand(a))));% sunset time
intsr=floor(Sr)+1;
intss=floor(Ss);
Ws=acosd((-tand(l)*tand(a)));%sunrise angle
T=Ss-Sr;%total day time

timlet=[Sr,intsr:0.25:intss,Ss];
p=length(timlet);

%Powerrear=zeros(1,p);
for i=1:(p)
    ws=(-Ws+(((2*Ws)/T)*(timlet(i)-Sr)));%hour angle

%------------
timle(i)=(timlet(i));

bft=acosd(cosd(ws)*cosd(23.5)); % beta/tilt too
  % -----------------
  beta=23.5;
%   refactp = ((1+cosd(beta))/2);
% difactm = ((1-cosd(beta))/2); %sky
refactprear = ((1+cosd(beta))/2);
difactmrear = ((1-cosd(beta))/2); %sky
%refactpf = ((1-cosd(beta))/2);
difactmf = ((1+cosd(beta))/2); %sky
A=asind((sind(a)*sind(l))+(cosd(a)*cosd(l)*cosd(ws)));%solar altitude angle
Za=90-A;%zenith angle
%AM=(1/cosd(Za))
AM=(1/sind(A));
fys=asind((cosd(a)*sind(ws))/cosd(A));
fi2=asind(sind(ws)/(sind(beta))); %if surface azimuthal exist buddy

kosh= (cosd(A)* cosd(fys-0)*sind(beta))+(sind(A)*cosd(beta));
%kosh2=((sind(l-beta)*sind(a))+(cosd(l-beta)*cosd(a)*cosd(ws)));

Ib = AA*(exp(-kk*AM));
if(Ib==inf)
    Ib=0;
else
    Ib=AA*(exp(-kk*AM));
end
Io=1367*((0.7)^(AM^(0.678)));

% idt(i) = cc*Ib*difactm; 
% irt1(i) = alb*Ib*(sind(A)+cc)*refactp;

Idrect(i) = Ib*kosh;
idtrear = cc*Ib*difactmrear;
irtrear = alb*Ib*(sind(A)+cc)*refactprear;

idtfront = cc*Ib*difactmf;

%total(i)= irt1(i)+idt(i);

tttotal(i)= idtrear+irtrear+idtfront+Idrect(i);

total(i)= idtrear+irtrear+idtfront ;
end
figure(3)
X=sum(tttotal);
bitop= tttotal*1.15;
Energy_S=X*0.25;
TotalDirect=sum(Idrect);
plot(timle,tttotal,'k',timle,Idrect,'-.',timle,total,'-'),legend('Total Power', 'POWER','POWER REAR');
title('(SIFAT) Solar Irrediance of Bifacial Fixed Panel Jan 15')
xlabel('Time(Hours)')
ylabel('Irrediance(Watt/m^2)')
end
% figure
% n=[15,46,74,105,135,166,196,227,258,288,319,349];%days indexed
% [Time,Power,Powerrear,Totalpower]=akib2(2);
% Time
% Totalpower
% tttotal
% length(Totalpower)
% length(tttotal)
% %disp(Totalpower)
% plot(Time,Power,'--',Time,Powerrear,'-.',Time,Totalpower,'k'),legend('Power','Power Rear','Total Power');
% title('(AKIB) Solar Irrediance of Bifacial Fixed Panel JAN 15')
% xlabel('Time(Hours)')
% ylabel('Irrediance(Watt/m^2)')
% 
% 
% Tpowerd = abs(Totalpower-tttotal);
% Powerreard= abs(Powerrear-total);
% Powerd = abs(Power-Idrect);
% figure
% plot(Time,Tpowerd,'k',Time,Powerreard,'-.',Time,Powerd,'--'),legend('Total Power', 'POWER Rear','POWER');
% title('(Difference)Solar Irrediance of Bifacial Fixed Panel JAN 15')
% xlabel('Time(Hours)')
% ylabel('Irrediance(Watt/m^2)')