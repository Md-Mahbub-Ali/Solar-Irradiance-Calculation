function [timle,tttotal,bitop,Energy_S]=bifacialsinglesif(n,l,long)
n;
q=23.45;
a= q*(sind((n+284)*(360/365)));
tlt = 23.5;
AA = 1160+75*sind((360/365)*(n-275));
kk = 0.174+0.035*sind((360/365)*(n-100));
cc = 0.095+(0.04*sind((360/365)*(n-100)));
alb = 0.4;
Sr=12-((1/15)*(acosd(-tand(l)*tand(a))));%sunrise time
Ss=12+((1/15)*(acosd(-tand(l)*tand(a))));% sunset time
intsr=floor(Sr)+1;
intss=floor(Ss);
Ws=acosd((-tand(l)*tand(a)));%sunrise angle
T=Ss-Sr;%total day time

timle=[Sr,intsr:0.25:intss,Ss];
p=length(timle);

for i=1:(p)
    ws=(-Ws+(((2*Ws)/T)*(timle(i)-Sr)));%hour angle

bft=acosd(cosd(ws)*cosd(23.5)) ;% beta/tilt too
% % % % % % % % % % % % refactp = ((1+cosd(bft))/2);
% % % % % % % % % % % % difactm = ((1-cosd(bft))/2); %sky

beta=bft;

refactprear = ((1+cosd(23.5))/2);
difactmrear = ((1-cosd(23.5))/2); %sky
%refactpf = ((1-cosd(beta))/2);
difactmf = ((1+cosd(23.5))/2); %sky




A=asind((sind(a)*sind(l))+(cosd(a)*cosd(l)*cosd(ws)));%solar altitude angle
Za=90-A;%zenith angle
AM=(1/cosd(Za));
 fys=asind((cosd(a)*sind(ws))/cosd(A));
% 
% 
 fi2=asind(sind(ws)/(sind(bft))) ;%if surface azimuthal exist buddy
% 
 kosh= (cosd(A)* cosd(fys-fi2)*sind(bft))+(sind(A)*cosd(bft))%
%kosh2=((sind(l-bft)*sind(a))+(cosd(l-bft)*cosd(a)*cosd(ws)));
Ib = AA*(exp(-kk*AM));
if(Ib==inf)
    Ib=0;
else
    Ib=AA*(exp(-kk*AM));
end
Io=1367*((0.7)^(AM^(0.678)));

% % % % % % % idt(i) = cc*Ib*difactm; 
% % % % % % % irt1(i) = alb*Ib*(sind(A)+cc)*refactp;

Idrect(i) = Ib*kosh;


idtrear = cc*Ib*difactmrear;
irtrear = alb*Ib*(sind(A)+cc)*refactprear;

idtfront = cc*Ib*difactmf;
%irtfront = alb*Ib*(sind(A)+cc)*refactpf;


%total(i)= irt1(i)+idt(i);
total(i)=idtrear+irtrear;
I(i)=idtfront+Idrect(i);
%%%%%%%%%%%%%%%%%tttotal(i)= idt(i)+irt1(i)+Idrect(i);
tttotal(i)= idtrear+irtrear+idtfront+Idrect(i);


end


X=sum(tttotal);
bitop= tttotal*1.15;
Energy_S=X*0.25


% figure(4)
% %plot (timle,tttotal,'k')
% plot (timle,tttotal,'k',timle,I,'-.',timle,total,'-'),legend('Total Power', 'POWER','POWER REAR');
% ylabel('Time(Hours)')
% xlabel('Irrediance(Watt/m^2)')
% str=sprintf('(SIFAT)Solar Irrediance of Bifacial Single Axis January', n);
% title(str);
end