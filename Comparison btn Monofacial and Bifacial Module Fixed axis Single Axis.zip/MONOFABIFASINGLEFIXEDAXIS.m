clc;
close all;
clear all;

n=15;
l=23.5;
long=90.40;

[timle,monotbsingle,Energy_monosingle]=monocialsinglesif(n,l,long);

[timle,tttotalsingle,bitop,Energy_bifasingle]=bifacialsinglesif(n,l,long);


Energy_bifasingle
Energy_monosingle

[timle,monotbfix,Energy_monofix]=monocialfixsif(n,l,long);

[timlet,tttotalfix,Energy_bifafixed]=bifacialfixsif(n,l,long);

Energy_bifafixed
Energy_monofixed=Energy_monofix





figure(255)
plot(timle,tttotalsingle,'k',timle,tttotalfix,'-.',timle,monotbsingle,'-',timle,monotbfix,':'),legend('Bifacial Single', 'Bifacial Fixed','Monofacial Single','Monofacial Fixed');
ylim([0 1500])
%title('(MAHBUB)Solar Irrediance of Bifacial Mid Panel January 15')
xlabel('Time(Hours)')
ylabel('Irradiance(Watt/m^2)')